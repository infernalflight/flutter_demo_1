class Todo {

  String _name;
  String _desc;

  Todo(this._name, this._desc);

  String get desc => _desc;

  String get name => _name;
}