import 'package:flutter/material.dart';

class TitrePage extends StatelessWidget
{
  @override
  Widget build(BuildContext context) {
    return Text('Titre de la liste');
  }

}